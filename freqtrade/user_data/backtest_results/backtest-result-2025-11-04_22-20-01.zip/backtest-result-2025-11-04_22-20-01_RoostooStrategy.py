# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
# --- Do not remove these imports ---
import numpy as np
import pandas as pd
from pandas import DataFrame
from roostoo_trade_client import RoostooAPIClient
import logging

IS_LIVE_TRADING = False  # roostoo

from freqtrade.strategy import IStrategy
import talib.abstract as ta


class RoostooStrategy(IStrategy):
    """
    Simple MACD strategy for testing
    """

    api_client = RoostooAPIClient()  # roostoo

    INTERFACE_VERSION = 3
    can_short: bool = False
    minimal_roi = {"0": 0.05}
    stoploss = -0.1
    timeframe = "1m"
    process_only_new_candles = True
    use_exit_signal = True
    startup_candle_count: int = 30

    def informative_pairs(self):
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # MACD
        macd = ta.MACD(dataframe)
        dataframe["macd"] = macd["macd"]
        dataframe["macdsignal"] = macd["macdsignal"]
        dataframe["macdhist"] = macd["macdhist"]

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                # MACD crosses above signal line
                (dataframe["macd"] > dataframe["macdsignal"])
                & (dataframe["macdhist"] > 0)
                & (dataframe["volume"] > 0)
            ),
            "enter_long",
        ] = 1

        # roostoo
        if IS_LIVE_TRADING:
            if dataframe.iloc[-1]["enter_long"] == 1:
                logging.info(f'entering long for pair: {metadata["pair"].replace("/USDT", "/USD")}')
                self.api_client.wrapped_buy(metadata["pair"].replace("/USDT", "/USD"))
                logging.info(self.api_client.get_balance())

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                # MACD crosses below signal line
                (dataframe["macd"] < dataframe["macdsignal"])
                & (dataframe["macdhist"] < 0)
                & (dataframe["volume"] > 0)
            ),
            "exit_long",
        ] = 1

        # roostoo
        if IS_LIVE_TRADING:
            if dataframe.iloc[-1]["exit_long"] == 1:
                self.api_client.wrapped_sell(metadata["pair"].replace("/USDT", "/USD"))
                logging.info(self.api_client.get_balance())

        return dataframe
